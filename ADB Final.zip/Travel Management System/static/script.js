(function () {
    'use strict'

    const forms = document.querySelectorAll('.needs-validation')

    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }

            form.classList.add('was-validated')
        }, false)
    })
})()

const costMap = {
    "Mumbai-Delhi": 1000,
    "Mumbai-Banglore": 2000,
    "Mumbai-Hydrabad": 1500,
    "Mumbai-Chennai": 1897,
    "Mumbai-Kolkata": 1699,
    "Mumbai-Pune": 1299,
    "Mumbai-Ahmedabad": 1200,
    "Delhi-Mumbai": 1000,
    "Delhi-Banglore": 2000,
    "Delhi-Hydrabad": 1500,
    "Delhi-Chennai": 1897,
    "Delhi-Kolkata": 1699,
    "Delhi-Pune": 1299,
    "Delhi-Ahmedabad": 1200,
    "Banglore-Mumbai": 1000,
    "Banglore-Delhi": 2000,
    "Banglore-Hydrabad": 1500,
    "Banglore-Chennai": 1897,
    "Banglore-Kolkata": 1699,
    "Banglore-Pune": 1299,
    "Banglore-Ahmedabad": 1200,
    "Hydrabad-Mumbai": 1000,
    "Hydrabad-Delhi": 2000,
    "Hydrabad-Hydrabad": 1500,
    "Hydrabad-Chennai": 1897,
    "Hydrabad-Kolkata": 1699,
    "Hydrabad-Pune": 1299,
    "Chennai-Ahmedabad": 1200,
    "Chennai-Mumbai": 1000,
    "Chennai-Delhi": 2000,
    "Chennai-Hydrabad": 1500,
    "Chennai-Chennai": 1897,
    "Chennai-Kolkata": 1699,
    "Chennai-Pune": 1299,
    "Chennai-Ahmedabad": 1200,
    "Chennai-Ahmedabad": 1200,
    "Kolkata-Mumbai": 1000,
    "Kolkata-Delhi": 2000,
    "Kolkata-Hydrabad": 1500,
    "Kolkata-Chennai": 1897,
    "Kolkata-Kolkata": 1699,
    "Kolkata-Pune": 1299,
    "Kolkata-Ahmedabad": 1200,
    "Pune-Mumbai": 1000,
    "Pune-Delhi": 2000,
    "Pune-Hydrabad": 1500,
    "Pune-Chennai": 1897,
    "Pune-Kolkata": 1699,
    "Pune-Pune": 1299,
    "Pune-Ahmedabad": 1200,
    "Ahmedabad-Mumbai": 1000,
    "Ahmedabad-Delhi": 2000,
    "Ahmedabad-Hydrabad": 1500,
    "Ahmedabad-Chennai": 1897,
    "Ahmedabad-Kolkata": 1699,
    "Ahmedabad-Pune": 1299,
    "Ahmedabad-Ahmedabad": 1200,
};

// Get references to your elements
const sourceDropdown = document.getElementById("source");
const destinationDropdown = document.getElementById("destination");
const totalCostDisplay = document.getElementById("totalCostDisplay");

// Add a "change" event listener to the source and destination dropdowns
sourceDropdown.addEventListener("change", updateCost);
destinationDropdown.addEventListener("change", updateCost);

// Define a function to calculate and update the cost
function updateCost() {
    const source = sourceDropdown.value;
    const destination = destinationDropdown.value;
    const route = source + "-" + destination;
    const cost = costMap[route];

    totalCostDisplay.value = cost;
}

// Optionally, you can call the updateCost function when the page loads
updateCost();


// document.getElementById("myForm").addEventListener("submit", function (event) {
//     event.preventDefault(); // Prevent the form from submitting

//     if (this.checkValidity()) {
//         alert("Form is valid. Submitting the form.");
//     }

//     this.classList.add("was-validated"); // Trigger Bootstrap's custom validation styles
// });
